from delpro import *
#CRATE VMESS

@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
	async def create_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 3 DAY •","3"),
Button.inline("• 7 DAY •","7")],
[Button.inline("• 30 DAY •","30"),
Button.inline("• 60 DAY •","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'printf "%s\n" "1" "{user}" "{exp}" "2" "{exp}" | add-ws'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
			print(b)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
**━━━━━━━━━━━━━━━━━**
**⚡XRAY VMESS ACCOUNT⚡**
**━━━━━━━━━━━━━━━━━**
**  Remarks     :** `{user}`
**  Host Server :** `{DOMAIN}`
**  User Quota  :** `{pw} GB`
**  port TLS    :** `443`
**  Port NTLS   :** `80, 8080,`
**  NetWork     :** `(WS) or (gRPC)`
**  User ID     :** `{uuid}`
**  Path Vless  :** `/vmess `
**  ServiceName :** `vmess`
**━━━━━━━━━━━━━━━━━**
**     LINK TLS     **
**━━━━━━━━━━━━━━━━━**
   `{x[0]}`
**━━━━━━━━━━━━━━━━━**
**     LINK NTLS   **
**━━━━━━━━━━━━━━━━━**
   `{x[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**     LINK GRPC   **
**━━━━━━━━━━━━━━━━━**
   `{x[2].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**  Format OpenClash :** https://{DOMAIN}:81/vless-{user}.txt
**━━━━━━━━━━━━━━━━━**
**  Expired Until:** `{later}`
**  @delpro2**
**━━━━━━━━━━━━━━━━━**

"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trl vmess'))
async def trial_vmess(event):
	async def trial_vmess_(event):
	async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Menit ","10"),
Button.inline(" 15 Menit ","15")],
[Button.inline(" 30 Menit ","30"),
Button.inline(" 60 Menit ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
	    user = "trialX"+str(random.randint(100,1000))
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(3)
		await event.edit("`Processing Create Premium Account`")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")


		cmd = f'printf "%s\n" "{exp}" "{user}" | tmux new-session -d -s {user} "trial trialws {user} {exp}" | triall-ws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
			print(b)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
**━━━━━━━━━━━━━━━━━**
**⚡TRIALLVMESS ACCOUNT⚡**
**━━━━━━━━━━━━━━━━━**
**  Remarks     :** `{user}`
**  Host Server :** `{DOMAIN}`
**  User Quota  :** `{pw} GB`
**  port TLS    :** `443`
**  Port NTLS   :** `80, 8080,`
**  NetWork     :** `(WS) or (gRPC)`
**  User ID     :** `{uuid}`
**  Path Vless  :** `/vmess `
**  ServiceName :** `vmess`
**━━━━━━━━━━━━━━━━━**
**     LINK TLS     **
**━━━━━━━━━━━━━━━━━**
   `{x[0]}`
**━━━━━━━━━━━━━━━━━**
**     LINK NTLS   **
**━━━━━━━━━━━━━━━━━**
   `{x[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**     LINK GRPC   **
**━━━━━━━━━━━━━━━━━**
   `{x[2].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**  Format OpenClash :** https://{DOMAIN}:81/vless-{user}.txt
**━━━━━━━━━━━━━━━━━**
**  Expired Until:** `{later}`
**  @delpro2**
**━━━━━━━━━━━━━━━━━**

"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'cek-ws'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Shows Logged In Users Vmess**
**@delpro2**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | del-ws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User deleted**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" TRIAL VMESS ","trl vmess")],
[Button.inline(" CREATE VMESS ","create-vmess")],
[Button.inline(" DELETE VMESS ","delete-vmess")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**━━━━━━━━━━━━━━━━━**
** ⚡ VMESS MANAGER ⚡**
**━━━━━━━━━━━━━━━━━**
** Service:** `VMESS`
** Hostname/IP:** `{DOMAIN}`
** ISP:** `{z["isp"]}`
** Country:** `{z["country"]}`
** @delpro2**
**━━━━━━━━━━━━━━━━━**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

