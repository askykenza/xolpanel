from xolpanel import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" SSH OVPN ","ssh")],
[Button.inline(" VMESS ","vmess"),
Button.inline(" TROJAN ","trojan")],
[Button.inline(" VLESS ","vless")],
[Button.inline(" CHECK VPS INFO ","info"),
Button.inline(" OTHER SETTING ","setting")],
[Button.url(" Telegram Channel ","https://t.me/cybervpn2")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	ifif val == "false":
		try:
			await event.answer("Acces Denied", alert=True)
		except:
			await event.reply("Acces Denied")
	elif val == "true":
		msg = f"""
**━━━━━━━━━━━━━━━━━**
**🔰CYBERVPN  BOT  🔰**
**━━━━━━━━━━━━━━━━━**
** 🖥️OS     :** `{namaos.strip().replace('"','')}`
** 🌏DOMAIN :** `{DOMAIN}`
** 🖥️IP VPS :** `{ipsaya.strip()}`
** 💵CREDIT BOT  BY: CyberVPN**

**━━━━━━━━━━━━━━━━━**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)


